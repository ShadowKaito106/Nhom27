package com.example.DeviceSellingProject.controller;

public class PaymentMomoRequest {
    private long amount;

    // Getters and setters
    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

}
