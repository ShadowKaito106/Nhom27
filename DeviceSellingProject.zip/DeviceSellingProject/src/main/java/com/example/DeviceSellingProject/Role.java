package com.example.DeviceSellingProject;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum Role {
    ADMIN(1),
    CUSTOMER(2),
    EMPLOYER(3);
    public final long value;
}
