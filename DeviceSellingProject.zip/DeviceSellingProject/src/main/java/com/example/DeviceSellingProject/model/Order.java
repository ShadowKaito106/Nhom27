package com.example.DeviceSellingProject.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Length;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    @Column(updatable = false, nullable = false)
    private String id;

    private String customerName;

    private String address;

    @Column(name = "email", length = 50)
    @Email
    private String email;

    @Column(name = "phone", length = 10)
    @Length(min = 10, max = 10, message = "Số điện thoại phải có 10 số.")
    private String phone;

    private String note;

    private LocalDate createdDate;

    private double totalPrice;

    private boolean status;

    @OneToMany(mappedBy = "order")
    private List<OrderDetails> orderDetails;

    @OneToOne(mappedBy = "order", cascade = CascadeType.ALL)
    private Invoice invoice;
}
