package com.example.DeviceSellingProject.config;

public enum PaypalPaymentIntent {
    sale, authorize,order
}
