package com.example.DeviceSellingProject.repositories;

import com.example.DeviceSellingProject.model.ProductDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDetailsRepository extends JpaRepository<ProductDetails, Long> {
}
