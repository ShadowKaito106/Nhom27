package com.example.DeviceSellingProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeviceSellingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeviceSellingProjectApplication.class, args);
	}

}
