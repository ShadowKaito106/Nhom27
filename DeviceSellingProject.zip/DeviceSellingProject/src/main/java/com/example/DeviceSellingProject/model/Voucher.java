package com.example.DeviceSellingProject.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "promotion")
public class Voucher {
    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(
            name = "UUID",
            strategy = "org.hibernate.id.UUIDGenerator"
    )
    private String id;

    private String name;

    private String code;

    private LocalDate createdDate;

    private LocalDate startDate;

    private LocalDate endDate;

    private float discount;

    private int quantity;

    @ManyToOne
    @JoinColumn(name = "category_id")
    public Category category;
}
