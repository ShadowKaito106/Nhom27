package com.example.DeviceSellingProject.repositories;

import com.example.DeviceSellingProject.model.CartItem;
import com.example.DeviceSellingProject.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CartRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser_Id(Long userId);
    Optional<CartItem> findByProduct_IdAndUser(Long productId, User user);
    void deleteByUser(User user);
}
