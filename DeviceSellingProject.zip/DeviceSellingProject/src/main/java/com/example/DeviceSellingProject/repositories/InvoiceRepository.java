package com.example.DeviceSellingProject.repositories;

import com.example.DeviceSellingProject.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findByUserId(Long userId);
    List<Invoice> findByCreatedDate(LocalDate date);
    @Query("SELECT p.category.name, SUM(od.quantity), SUM(od.quantity * p.price) " +
            "FROM Invoice i JOIN i.order o " +
            "JOIN OrderDetails od ON o.id = od.order.id " +
            "JOIN Product p ON od.product.id = p.id " +
            "GROUP BY p.category.name " +
            "ORDER BY SUM(od.quantity) DESC")
    List<Object[]> findTopSellingCategories();
}
