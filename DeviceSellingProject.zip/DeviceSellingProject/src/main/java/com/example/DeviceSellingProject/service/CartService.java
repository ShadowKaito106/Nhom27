package com.example.DeviceSellingProject.service;

import com.example.DeviceSellingProject.model.CartItem;
import com.example.DeviceSellingProject.model.Product;
import com.example.DeviceSellingProject.model.User;
import com.example.DeviceSellingProject.model.Voucher;
import com.example.DeviceSellingProject.repositories.CartRepository;
import com.example.DeviceSellingProject.repositories.IUserRepository;
import com.example.DeviceSellingProject.repositories.ProductRepository;
import com.example.DeviceSellingProject.repositories.VoucherRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.annotation.SessionScope;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@SessionScope
@Getter
public class CartService {
    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private IUserRepository userRepository;

    @Autowired
    private VoucherRepository voucherRepository;

    public List<CartItem> getCartItems(Long userId) {
        return cartRepository.findByUser_Id(userId);
    }

    @Transactional
    public void addToCart(Long userId, Long productId, int quantity, String size) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalStateException("Không tìm thấy người dùng này"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalStateException("Không tìm thấy sản phẩm này"));

        Optional<CartItem> existingCartItem = cartRepository.findByProduct_IdAndUser(productId, user);

        if (existingCartItem.isPresent()) {
            CartItem cartItem = existingCartItem.get();
            cartItem.setQuantity(cartItem.getQuantity() + quantity);
            cartRepository.save(cartItem);
        } else {
            CartItem cartItem = new CartItem(product, quantity, size, user);
            cartRepository.save(cartItem);
        }
    }

    @Transactional
    public void removeFromCart(Long userId, Long cartItemId) {
        CartItem cartItem = cartRepository.findById(cartItemId)
                .orElseThrow(() -> new IllegalStateException("Không tìm thấy sản phẩm này"));

        if (!cartItem.getUser().getId().equals(userId)) {
            throw new IllegalStateException("Unauthorized operation");
        }

        cartRepository.delete(cartItem);
    }

    @Transactional
    public void clearCart(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalStateException("Không tìm thấy người dùng này"));

        cartRepository.deleteByUser(user);
    }

    @Transactional
    public void updateCart(Long userId, Map<Long, Integer> productQuantities) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalStateException("Không tìm thấy người dùng này"));

        List<CartItem> cartItems = cartRepository.findByUser_Id(userId);

        if (cartItems.isEmpty()) {
            throw new EntityNotFoundException("Không tìm thấy sản phẩm nào trong giỏ hàng");
        }

        for (CartItem cartItem : cartItems) {
            Long productId = cartItem.getProduct().getId();
            if (productQuantities.containsKey(productId)) {
                int newQuantity = productQuantities.get(productId);
                if (cartItem.getQuantity() != newQuantity) {
                    cartItem.setQuantity(newQuantity);
                    cartRepository.save(cartItem);
                }
            }
        }
    }

    public double calculateTotalCost(List<CartItem> cartItems) {
        return cartItems.stream().mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity()).sum();
    }
    @Transactional
    public boolean applyVoucher(Long userId, String voucherCode) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Voucher voucher = voucherRepository.findByCode(voucherCode).orElse(null);

        if (voucher == null || voucher.getQuantity() <= 0 || voucher.getEndDate().isBefore(LocalDate.now())) {
            return false;
        }

        List<CartItem> cartItems = cartRepository.findByUser_Id(userId);
        if (cartItems.isEmpty()) {
            return false;
        }

        // Apply discount to each cart item
        cartItems.forEach(item -> {
            long discountedPrice = (long) (item.getProduct().getPrice() * item.getQuantity() * (1 - voucher.getDiscount() / 100));
            item.setTotalPrice(discountedPrice);
        });

        // Decrease the voucher quantity
        voucher.setQuantity(voucher.getQuantity() - 1);
        voucherRepository.save(voucher);

        // Save the updated cart items
        cartRepository.saveAll(cartItems);

        return true;
    }

    public String getAppliedVoucherCode(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getAppliedVoucherCode() : null;
    }

    public Voucher getVoucherByCode(String voucherCode) {
        return voucherRepository.findByCode(voucherCode).orElse(null);
    }
}