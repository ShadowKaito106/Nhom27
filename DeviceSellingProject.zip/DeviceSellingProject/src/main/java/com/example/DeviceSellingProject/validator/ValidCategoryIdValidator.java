package com.example.DeviceSellingProject.validator;

import com.example.DeviceSellingProject.model.Category;
import com.example.DeviceSellingProject.validator.annotation.ValidCategoryId;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ValidCategoryIdValidator implements ConstraintValidator<ValidCategoryId, Category> {
    @Override
    public boolean isValid(Category category, ConstraintValidatorContext constraintValidatorContext) {
        return category != null && category.getId() !=null;
    }
}
