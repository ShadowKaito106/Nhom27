package com.example.DeviceSellingProject.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
@Configuration
@Component
@ConfigurationProperties(prefix = "momo")
public class MomoConfig {

    @Value("${momo.partnerCode}")
    private String partnerCode;

    @Value("${momo.accessKey}")
    private String accessKey;

    @Value("${momo.secretKey}")
    private String secretKey;

    @Value("${momo.endpoint}")
    private String endpoint;

    @Value("${momo.returnUrl}")
    private String returnUrl;

    @Value("${momo.notifyUrl}")
    private String notifyUrl;

    public String getConstructedReturnUrl(String resultCode) {
        return UriComponentsBuilder.fromHttpUrl(returnUrl)
                .queryParam("resultCode", resultCode)
                .build().toUriString();
    }
}
