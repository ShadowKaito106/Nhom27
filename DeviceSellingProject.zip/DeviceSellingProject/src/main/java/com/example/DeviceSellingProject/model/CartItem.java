package com.example.DeviceSellingProject.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "cart")
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    private int quantity;

    private String size;

    private long totalPrice;

    @Transient
    private String formattedPrice;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public CartItem(Product product, int quantity, String size, User user) {
        this.product = product;
        this.quantity = quantity;
        this.size = size;
        this.user = user;
        this.totalPrice = product.getPrice() * quantity;
    }
    public void applyDiscount(float discount) {
        this.totalPrice = (long) (product.getPrice() * quantity * (1 - discount / 100));
    }
}
