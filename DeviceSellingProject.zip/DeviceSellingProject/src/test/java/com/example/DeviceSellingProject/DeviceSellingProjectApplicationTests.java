package com.example.DeviceSellingProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceSellingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
